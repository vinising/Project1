package org.upgrad.upstac.users.roles;

public enum UserRole {
    USER, TESTER, DOCTOR,GOVERNMENT_AUTHORITY
}
